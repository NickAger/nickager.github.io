//: Accompanying the blog post: http://nickager.com/blog/2016/04/20/avoiding-any-arrays
// inspired by: http://www.csinaction.com/2014/11/24/implementing-rubys-array-flatten-in-haskell/

import Foundation

enum IntOrArray {
    case intValue(Int)
    case arrayValue([IntOrArray])
}

// let a : [Any] = [1,2,[3],[4,[5,6]],[[7]], 8]
// equivalent in a type-safe way:
let a : [IntOrArray] = [.intValue(1), .intValue(2), .arrayValue([.intValue(4), .arrayValue([.intValue(5), .intValue(6)])]), .arrayValue([.arrayValue([.intValue(7)])]), .intValue(8)]

func process(anArray : [IntOrArray]) {
    for element in anArray {
        switch(element) {
        case .intValue(let intValue):
            print("intValue = \(intValue)")
        case .arrayValue(let arrayValue):
            process(arrayValue)
           
        }
    }
}

process(a)

func flatten(anArray : [IntOrArray]) -> [Int] {
    return anArray.flatMap (flattenAnElement)
}

func flattenAnElement (element : IntOrArray) -> [Int] {
    switch element {
    case .intValue(let intValue):
        return [intValue]
        
    case .arrayValue(let arrayValue):
        return flatten(arrayValue)
    }
}

flatten(a)